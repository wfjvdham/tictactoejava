package bot;

public class ScoreDepth {
	private int score;
	private int depth;
	
	public ScoreDepth(int score, int depth) {
		this.score = score;
		this.depth = depth;
	}
	
	public int getScore() {
		return score;
	}
	
	public int getDepth() {
		return depth;
	}
}
